-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 27, 2019 at 01:08 PM
-- Server version: 5.7.24
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `catalogl6`
--

-- --------------------------------------------------------

--
-- Table structure for table `goods`
--

CREATE TABLE `goods` (
  `id` int(5) NOT NULL,
  `name` varchar(25) NOT NULL,
  `description` text NOT NULL,
  `category` int(3) NOT NULL DEFAULT '1',
  `image` varchar(255) NOT NULL,
  `price` int(10) DEFAULT NULL,
  `views_count` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `goods`
--

INSERT INTO `goods` (`id`, `name`, `description`, `category`, `image`, `price`, `views_count`) VALUES
(16, 'Brasil', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean condimentum scelerisque nisl ac porta. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam eget vestibulum enim. Phasellus pharetra suscipit gravida. Duis volutpat mi ut fermentum tempus. Mauris sagittis urna et ligula feugiat, eget laoreet libero feugiat. Quisque malesuada a libero eget dignissim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam eu auctor orci. Suspendisse luctus feugiat sapien sit amet molestie. In ut nulla magna.', 1, 'upload/1577298272-iconfinder_Flag_of_Brazil_96143.png', 10000, 0),
(17, 'Austria', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean condimentum scelerisque nisl ac porta. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam eget vestibulum enim. Phasellus pharetra suscipit gravida. Duis volutpat mi ut fermentum tempus. Mauris sagittis urna et ligula feugiat, eget laoreet libero feugiat. Quisque malesuada a libero eget dignissim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam eu auctor orci. Suspendisse luctus feugiat sapien sit amet molestie. In ut nulla magna.', 1, 'upload/1577298741-iconfinder_Flag_of_Austria_96139.png', 12000, 0),
(18, 'Chakhia', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean condimentum scelerisque nisl ac porta. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam eget vestibulum enim. Phasellus pharetra suscipit gravida. Duis volutpat mi ut fermentum tempus. Mauris sagittis urna et ligula feugiat, eget laoreet libero feugiat. Quisque malesuada a libero eget dignissim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam eu auctor orci. Suspendisse luctus feugiat sapien sit amet molestie. In ut nulla magna.', 1, 'upload/1577370648-iconfinder_Flag_of_Czech_Republic_96321.png', 9000, 0),
(19, 'England', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean condimentum scelerisque nisl ac porta. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam eget vestibulum enim. Phasellus pharetra suscipit gravida. Duis volutpat mi ut fermentum tempus. Mauris sagittis urna et ligula feugiat, eget laoreet libero feugiat. Quisque malesuada a libero eget dignissim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam eu auctor orci. Suspendisse luctus feugiat sapien sit amet molestie. In ut nulla magna.', 1, 'upload/1577386421-australia.png', 15000, 0),
(21, 'Shwis', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean condimentum scelerisque nisl ac porta. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam eget vestibulum enim. Phasellus pharetra suscipit gravida. Duis volutpat mi ut fermentum tempus. Mauris sagittis urna et ligula feugiat, eget laoreet libero feugiat. Quisque malesuada a libero eget dignissim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam eu auctor orci. Suspendisse luctus feugiat sapien sit amet molestie. In ut nulla magna.', 1, 'upload/1577428492-iconfinder_Flag_of_Switzerland_96240.png', 8000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `orderlist`
--

CREATE TABLE `orderlist` (
  `id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `good_id` int(5) NOT NULL,
  `quantity` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderlist`
--

INSERT INTO `orderlist` (`id`, `order_id`, `good_id`, `quantity`) VALUES
(55, 34, 17, 1),
(56, 34, 18, 2),
(57, 35, 17, 1),
(58, 35, 18, 2),
(59, 36, 17, 1),
(60, 36, 16, 1),
(61, 37, 16, 1),
(62, 37, 17, 2),
(63, 37, 18, 1),
(64, 37, 19, 1),
(65, 37, 21, 1),
(66, 38, 16, 1),
(67, 39, 17, 1),
(68, 40, 16, 1),
(69, 40, 17, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `status_id` int(3) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `status_id`) VALUES
(34, 44, 2),
(35, 44, 2),
(36, 44, 0),
(37, 44, 0),
(38, 44, 0),
(39, 43, 0),
(40, 43, 0);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(5) NOT NULL,
  `good_id` int(5) NOT NULL,
  `author` varchar(25) NOT NULL,
  `text` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `good_id`, `author`, `text`, `date`) VALUES
(1, 1, 'Anna', 'I like it. Very nice dress.', '2019-11-13 12:12:08'),
(2, 1, 'Milana', 'I don\'t like the quality of this dress. Its so so...', '2019-11-12 06:00:12'),
(4, 2, 'Mary', 'Good choise ', '2019-11-13 20:00:49'),
(5, 2, 'test', ' hello', '2019-11-14 08:34:03'),
(6, 1, 'IRINA', ' I bought this dress last week. Its so nice', '2019-11-14 08:35:27'),
(7, 2, 'Alisa', ' I can recommend this dress. Its ok', '2019-11-14 08:53:25'),
(8, 2, 'Anna', ' Its one more test', '2019-11-14 08:55:44'),
(9, 1, 'Silver', 'I test it again and again ', '2019-11-14 08:56:15'),
(10, 1, 'Begood', 'A little test ', '2019-11-14 09:32:08'),
(11, 2, 'Мария', 'Мне очень понравилось это платье. ', '2019-11-20 17:48:37'),
(12, 4, 'Alexa', 'Test review ', '2019-11-29 15:41:38');

-- --------------------------------------------------------

--
-- Table structure for table `statuslist`
--

CREATE TABLE `statuslist` (
  `status_id` int(3) NOT NULL,
  `status_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `statuslist`
--

INSERT INTO `statuslist` (`status_id`, `status_name`) VALUES
(0, 'Принят'),
(1, 'Подтвержден'),
(2, 'Отправлен'),
(3, 'Получен');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `role` int(2) NOT NULL DEFAULT '1',
  `name` varchar(50) NOT NULL,
  `tel` varchar(50) DEFAULT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role`, `name`, `tel`, `login`, `password`) VALUES
(43, 2, 'admin', '2', 'admin', 'c81e728d9d4c2f636f067f89cc14862c'),
(44, 1, 'guest', '89110285853', 'guest', 'c4ca4238a0b923820dcc509a6f75849b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderlist`
--
ALTER TABLE `orderlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `orderlist`
--
ALTER TABLE `orderlist`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
